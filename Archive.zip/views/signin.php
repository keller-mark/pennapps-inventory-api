<!DOCTYPE html>
<html>
<body>

<form action="/">
  First name:<br>
  <input type="text" name="Employee no." value="xxxx-xxxx-xxxx-xxxx">
  <br>
  <input type="submit" value="Submit">
</form>

<p>Swipe to see inventory.</p>

</body>
</html>
